<?php
    // include constants.php for ISTEURL
    include('../config/constants.php');

    // 1. destroy the session 
    session_destroy(); // Unsets $_SESSION['user']


    // 2. redirect to login
    header('location'.SITEURL.'admin/login.php');
?>