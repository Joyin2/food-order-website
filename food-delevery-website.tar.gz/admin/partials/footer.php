  <!-- Footer Section Starts -->
  <div class="footer">

<div class="wrapper footer">
    <p class="text-center">
        2021 all rights reserved, MyRestaurant Developed By - Joyin
    </p>
</div>
</div>
<!-- Footer Section Ends -->
</body>

</html>